USERS = {
    'user1': 'password1',
    'user2': 'password2'
}