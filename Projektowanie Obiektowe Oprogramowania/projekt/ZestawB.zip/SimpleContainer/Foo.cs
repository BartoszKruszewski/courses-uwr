public class Foo : IFoo
{
    public void Do() => System.Console.WriteLine("Foo");
}