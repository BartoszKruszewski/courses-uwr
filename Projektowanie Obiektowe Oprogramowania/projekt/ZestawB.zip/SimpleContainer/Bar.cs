public class Bar : IFoo
{
    public void Do() => System.Console.WriteLine("Bar");
}