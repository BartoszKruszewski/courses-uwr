public interface IFoo
{
    void Do();
}