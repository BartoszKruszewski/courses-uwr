public class WithString
{
    public string S { get; }
    public WithString(string s) => S = s;
}
