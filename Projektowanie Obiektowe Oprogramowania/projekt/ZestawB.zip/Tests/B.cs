public class B { }
