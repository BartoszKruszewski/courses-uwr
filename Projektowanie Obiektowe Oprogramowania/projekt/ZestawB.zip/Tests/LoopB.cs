public class LoopB
{
    public LoopB(LoopA a) { }
}
