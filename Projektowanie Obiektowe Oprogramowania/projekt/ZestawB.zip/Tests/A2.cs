public class A2
{
    public IC CDep { get; }
    public A2(IC c) => CDep = c;
}
