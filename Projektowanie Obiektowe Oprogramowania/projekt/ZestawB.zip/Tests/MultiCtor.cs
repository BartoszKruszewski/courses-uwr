public class MultiCtor
{
    public MultiCtor() { }
    public MultiCtor(B b, C c) { }
}
