public class C : IC { }
