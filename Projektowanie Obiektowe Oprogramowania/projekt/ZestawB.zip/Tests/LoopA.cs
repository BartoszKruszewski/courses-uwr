public class LoopA
{
    public LoopA(LoopB b) { }
}
