class Car:
    def __init__(self, make: str, year: int):
        self.make = make
        self.year = year
